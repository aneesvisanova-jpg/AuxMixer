package com.example.auxmixer

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {

    private lateinit var am: AudioManager
    private lateinit var statusIn: TextView
    private lateinit var statusOut: TextView
    private lateinit var toggle: Button
    private lateinit var gainLabel: TextView

    private val deviceCallback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(added: Array<out AudioDeviceInfo>?) = refreshStatus()
        override fun onAudioDevicesRemoved(removed: Array<out AudioDeviceInfo>?) = refreshStatus()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        am = getSystemService(Context.AUDIO_SERVICE) as AudioManager

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(48, 96, 48, 48)
        }

        statusIn = TextView(this).apply { textSize = 16f }
        statusOut = TextView(this).apply { textSize = 16f }

        toggle = Button(this).apply {
            textSize = 20f
            setOnClickListener { onToggle() }
        }

        gainLabel = TextView(this).apply { textSize = 16f; setPadding(0, 48, 0, 0) }
        val seek = SeekBar(this).apply {
            max = 300                       // 0% .. 300%
            progress = 100
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    AudioMixerService.gain = p / 100f
                    gainLabel.text = "PC volume gain: $p%"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        gainLabel.text = "PC volume gain: 100%"

        val hint = TextView(this).apply {
            text = "Tip: start at a low gain and raise it slowly. If you hear buzzing, lower it."
            textSize = 13f
            setPadding(0, 48, 0, 0)
        }

        root.addView(statusIn)
        root.addView(statusOut)
        root.addView(toggle, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 64 })
        root.addView(gainLabel)
        root.addView(seek, LinearLayout.LayoutParams(-1, -2))
        root.addView(hint)
        setContentView(root)

        refreshStatus()
    }

    override fun onStart() {
        super.onStart()
        am.registerAudioDeviceCallback(deviceCallback, null)
        refreshStatus()
    }

    override fun onStop() {
        am.unregisterAudioDeviceCallback(deviceCallback)
        super.onStop()
    }

    private fun onToggle() {
        if (AudioMixerService.running) {
            startService(Intent(this, AudioMixerService::class.java).setAction(AudioMixerService.ACTION_STOP))
            toggle.postDelayed({ refreshStatus() }, 300)
        } else {
            val needed = mutableListOf(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) needed += Manifest.permission.POST_NOTIFICATIONS
            val missing = needed.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
            if (missing.isNotEmpty()) {
                requestPermissions(missing.toTypedArray(), 1)
            } else {
                startMixer()
            }
        }
    }

    private fun startMixer() {
        startForegroundService(Intent(this, AudioMixerService::class.java).setAction(AudioMixerService.ACTION_START))
        toggle.postDelayed({ refreshStatus() }, 300)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startMixer()
        } else {
            Toast.makeText(this, "Microphone permission is required for the Aux input", Toast.LENGTH_LONG).show()
        }
    }

    private fun refreshStatus() {
        val inputs = am.getDevices(AudioManager.GET_DEVICES_INPUTS)
        val outputs = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        val aux = inputs.any {
            it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET || it.type == AudioDeviceInfo.TYPE_USB_HEADSET
        }
        val bt = outputs.any { it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP }

        statusIn.text = if (aux) "Aux input: CONNECTED" else "Aux input: not detected (phone mic will be used)"
        statusIn.setTextColor(if (aux) Color.rgb(0, 130, 0) else Color.rgb(200, 0, 0))
        statusOut.text = if (bt) "Bluetooth headphones: CONNECTED" else "Bluetooth headphones: not detected"
        statusOut.setTextColor(if (bt) Color.rgb(0, 130, 0) else Color.rgb(200, 0, 0))

        toggle.text = if (AudioMixerService.running) "STOP" else "START"
    }
}
