package com.example.auxmixer

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.*
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log

class AudioMixerService : Service() {

    companion object {
        const val ACTION_START = "com.example.auxmixer.START"
        const val ACTION_STOP = "com.example.auxmixer.STOP"
        private const val CHANNEL_ID = "aux_mixer_channel"
        private const val NOTIF_ID = 1
        private const val SAMPLE_RATE = 48000
        private const val TAG = "AudioMixerService"

        @Volatile var gain: Float = 1.0f      // set from the UI slider
        @Volatile var running: Boolean = false
    }

    @Volatile private var loopThread: Thread? = null
    @Volatile private var keepRunning = false
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopMixing()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        startInForeground()
        startMixing()
        return START_STICKY
    }

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Aux Mixer", NotificationManager.IMPORTANCE_LOW)
        )
        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, AudioMixerService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val notif = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Aux Mixer running")
            .setContentText("Routing Aux input to your headphones")
            .setSmallIcon(android.R.drawable.ic_lock_silent_mode_off)
            .setContentIntent(openApp)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "Stop", stop).build())
            .build()

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, notif)
        }
    }

    private fun startMixing() {
        if (keepRunning) return
        keepRunning = true
        running = true

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AuxMixer::Lock").apply {
            setReferenceCounted(false); acquire()
        }

        loopThread = Thread({ audioLoop() }, "AuxMixerLoop").also {
            it.priority = Thread.MAX_PRIORITY
            it.start()
        }
    }

    private fun stopMixing() {
        keepRunning = false
        running = false
        try { loopThread?.join(500) } catch (_: Exception) {}
        loopThread = null
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
    }

    private fun audioLoop() {
        android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO)
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager

        val minRec = AudioRecord.getMinBufferSize(
            SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val minPlay = AudioTrack.getMinBufferSize(
            SAMPLE_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (minRec <= 0 || minPlay <= 0) { Log.e(TAG, "Bad buffer size"); return }

        // Prefer UNPROCESSED (no AGC/noise suppression), fall back to MIC.
        val source = if (am.getProperty(AudioManager.PROPERTY_SUPPORT_AUDIO_SOURCE_UNPROCESSED) == "true")
            MediaRecorder.AudioSource.UNPROCESSED else MediaRecorder.AudioSource.MIC

        val recorder: AudioRecord
        val track: AudioTrack
        try {
            recorder = AudioRecord.Builder()
                .setAudioSource(source)
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(SAMPLE_RATE)
                        .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                        .build()
                )
                .setBufferSizeInBytes(minRec * 2)
                .build()

            // USAGE_MEDIA + no audio focus request = other apps keep playing; Android mixes everything.
            track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(SAMPLE_RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(minPlay)
                .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
        } catch (e: Exception) {
            Log.e(TAG, "Init failed", e)
            running = false
            return
        }

        // Route input = wired jack, output = Bluetooth A2DP (when present).
        am.getDevices(AudioManager.GET_DEVICES_INPUTS).firstOrNull {
            it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET || it.type == AudioDeviceInfo.TYPE_USB_HEADSET
        }?.let { recorder.setPreferredDevice(it) }

        am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).firstOrNull {
            it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP
        }?.let { track.setPreferredDevice(it) }

        val frames = minRec / 2
        val buf = ShortArray(frames)

        try {
            recorder.startRecording()
            track.play()
            while (keepRunning) {
                val n = recorder.read(buf, 0, buf.size)
                if (n <= 0) continue
                val g = gain
                for (i in 0 until n) {
                    val v = (buf[i] * g).toInt()
                    buf[i] = v.coerceIn(-32768, 32767).toShort()
                }
                track.write(buf, 0, n)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Loop error", e)
        } finally {
            try { recorder.stop() } catch (_: Exception) {}
            recorder.release()
            try { track.stop() } catch (_: Exception) {}
            track.release()
            running = false
        }
    }

    override fun onDestroy() {
        stopMixing()
        super.onDestroy()
    }
}
